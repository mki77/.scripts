### Command line calculator written in AutoIt3
This script supports most common mathematical expressions such as sin, cos, tan, log, exp, random number generation, etc.

```
Examples:
>2^^8
 256
>((2*3)+2/5)*100/42
 15.2380952380952
>BitOR(3, 15, 32)
 47
>Ceiling(10.1)
 11
>Exp(2)
 7.38905609893065
>Floor(10.1)
 10
>Log(2.71828182845905)
 1
>Log10(100)
 2
>Log2(64)
 1.80617997398389
>Mod(100, 15)
 10
>Round(10.49)
 10
>Random()
 0.920624644029886
>Random(1, 10)
 7.2000352954492
>Random(1, 10, 1)
 7
>Sqrt(9)
 3
>asin(0.5)
 0.523598775598299
>sin(0.5)
 0.479425538604203
```